
# 💧 Water Usage Dashboard with Quantum Optimization

This tool allows farm teams to track water usage by zone (e.g., Mushrooms, Greenhouse), visualize trends, simulate scenarios, and optimize efficiency using quantum-inspired risk scoring (via PennyLane).

---

## 📦 Features

- Simulated or sensor-based water monitoring
- Daily zone-based water usage summaries
- Quantum-inspired risk score (0 = efficient, 1 = wasteful)
- Scenario testing (overuse, drought, ideal)
- Visualization of total usage and efficiency over time

---

## 🧠 How Quantum Scoring Works

Each day is scored using a simulated qubit circuit:
- Inputs: Total water, mushrooms, greenhouse
- Outputs: Score from 0 (efficient) to 1 (wasteful)

---

## 🔧 Setup Instructions

1. Open the notebook in [Google Colab](https://colab.research.google.com/)
2. Run the cells in order
3. (Optional) Upload or generate water data
4. Run visualization and scoring functions

---

## 📁 File Overview

- `water_dashboard.ipynb` — Main notebook
- `requirements.txt` — Python packages
- `simulated_water_monitoring.csv` — Sample data

---

## 📜 License

MIT License — free to use and modify with attribution.
